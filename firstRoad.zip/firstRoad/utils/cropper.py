# utils/cropper.py
import torch
import torchvision.transforms.functional as F
from PIL import Image
from utils.logger import logger

class DynamicHighResCropper:
    """
    动态高分辨率裁切器 (Eagle-REC 核心亮点)
    负责从原始的高清大图中，根据阶段一的粗略候选框，抠出局部图块并 Resize。
    """
    def __init__(self, target_crop_size: int = 256, expand_ratio: float = 1.5):
        self.target_crop_size = (target_crop_size, target_crop_size)
        self.expand_ratio = expand_ratio # 将粗略框向外扩展 1.5 倍，提供充足上下文
        
        self.mean =[0.485, 0.456, 0.406]
        self.std =[0.229, 0.224, 0.225]

    def process_batch(self, orig_paths: list, coarse_bboxes: torch.Tensor, device: torch.device):
        """
        参数:
            orig_paths: 一个 batch 的原始 4K 图像的绝对路径
            coarse_bboxes: (B, 4) 阶段一预测出的归一化大框 (0~1 之间)
        返回:
            crop_tensors: (B, 3, 256, 256) 准备喂给阶段二的高清张量
        """
        batch_crops =[]
        
        # 将张量移到 CPU 以方便几何计算
        coarse_bboxes = coarse_bboxes.detach().cpu()
        
        for i, img_path in enumerate(orig_paths):
            try:
                # 重新读取未经任何降采样的高清原图
                img = Image.open(img_path).convert("RGB")
                w, h = img.size
                
                # 1. 将归一化坐标还原为原图的绝对坐标
                box = coarse_bboxes[i]
                # 使用 min 和 max 强制保证 x1 < x2, y1 < y2
                x1 = min(box[0], box[2]) * w
                x2 = max(box[0], box[2]) * w
                y1 = min(box[1], box[3]) * h
                y2 = max(box[1], box[3]) * h

                # 2. 向外扩张 (Padding)
                bw = x2 - x1
                bh = y2 - y1
                cx, cy = x1 + bw / 2, y1 + bh / 2
                
                new_bw = bw * self.expand_ratio
                new_bh = bh * self.expand_ratio
                
                # 极度安全的越界保护
                new_x1 = max(0.0, float(cx - new_bw / 2))
                new_y1 = max(0.0, float(cy - new_bh / 2))
                new_x2 = min(float(w), float(cx + new_bw / 2))
                new_y2 = min(float(h), float(cy + new_bh / 2))
                
                # 3. 灵魂操作：在无损原图上直接抠图！(Crop)
                # crop 接受的参数是 (top, left, height, width)
                cropped_img = F.crop(img, int(new_y1), int(new_x1), int(new_y2 - new_y1), int(new_x2 - new_x1))
                
                # 4. 转换并归一化
                tensor_img = F.to_tensor(cropped_img)
                tensor_img = F.resize(tensor_img, self.target_crop_size, interpolation=F.InterpolationMode.BILINEAR)
                tensor_img = F.normalize(tensor_img, mean=self.mean, std=self.std)
                
                batch_crops.append(tensor_img)
                
            except Exception as e:
                logger.error(f"裁切原图失败 {img_path}: {e}")
                # 容错：如果失败，塞一张黑图进去保证不崩
                batch_crops.append(torch.zeros(3, self.target_crop_size[0], self.target_crop_size[1]))

        # 拼接为一个大 Tensor (B, 3, 256, 256) 并送入 GPU
        return torch.stack(batch_crops).to(device)