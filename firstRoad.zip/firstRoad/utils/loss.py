# utils/loss.py
import torch
import torch.nn.functional as F
import torchvision.ops as ops

def box_iou(boxes1, boxes2):
    """安全的 IoU 计算 (坐标格式:[x1, y1, x2, y2])"""
    area1 = (boxes1[:, 2] - boxes1[:, 0]) * (boxes1[:, 3] - boxes1[:, 1])
    area2 = (boxes2[:, 2] - boxes2[:, 0]) * (boxes2[:, 3] - boxes2[:, 1])

    lt = torch.max(boxes1[:, :2], boxes2[:, :2])  # [N, 2]
    rb = torch.min(boxes1[:, 2:], boxes2[:, 2:])  #[N, 2]

    wh = (rb - lt).clamp(min=0)  #[N, 2]
    inter = wh[:, 0] * wh[:, 1]  # [N]

    union = area1 + area2 - inter
    iou = inter / union.clamp(min=1e-6)
    return iou, union

def generalized_box_iou(boxes1, boxes2):
    """安全的 GIoU 计算"""
    iou, union = box_iou(boxes1, boxes2)

    lt = torch.min(boxes1[:, :2], boxes2[:, :2])
    rb = torch.max(boxes1[:, 2:], boxes2[:, 2:])

    wh = (rb - lt).clamp(min=0)
    area = wh[:, 0] * wh[:, 1]

    giou = iou - (area - union) / area.clamp(min=1e-6)
    return giou



# loss_giou = ops.generalized_box_iou_loss(pred_bbox, target_bbox, reduction='mean')

class Stage1Loss(torch.nn.Module):
    """
    Eagle-REC 阶段一的联合损失函数
    """
    def __init__(self, lambda_distill=0.5):
        super().__init__()
        self.lambda_distill = lambda_distill

    def forward(self, pred_bbox, target_bbox, pred_semantic, target_semantic):
        # 1. Bounding Box 损失 (L1 + GIoU)
        loss_l1 = F.l1_loss(pred_bbox, target_bbox, reduction='mean')
        
        loss_giou = 1 - torch.diag(generalized_box_iou(pred_bbox, target_bbox)).mean()
        
        loss_bbox = loss_l1 + loss_giou
        
        # 2. 隐式蒸馏损失 (Cross Entropy)
        # target_semantic 需要是 long 类型，维度是 (Batch, H, W)，取值 0~14
        # 我们增加 ignore_index=255 防止脏数据导致的爆炸
        target_semantic = target_semantic.long()
        # 将无效类别 (如果超出了 14) 截断或忽略，保证安全
        #target_semantic = torch.clamp(target_semantic, min=0, max=14) 
        
        loss_semantic = F.cross_entropy(pred_semantic, target_semantic, ignore_index=255)
        
        # 3. 联合总 Loss
        total_loss = loss_bbox + self.lambda_distill * loss_semantic
        
        return total_loss, loss_bbox, loss_semantic