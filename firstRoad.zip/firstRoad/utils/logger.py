# utils/logger.py   全局安全日志
import logging
import sys

def get_logger(name="EagleREC"):
    """
    配置并返回一个标准化的日志记录器，防止重复打印。
    """
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)
    
    # 如果已经有 handler，说明被初始化过，直接返回，避免重复输出
    if not logger.handlers:
        formatter = logging.Formatter(
            fmt='[%(asctime)s] [%(levelname)s] %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        
        # 控制台输出
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setFormatter(formatter)
        logger.addHandler(console_handler)
        
    return logger

# 全局 logger 实例
logger = get_logger()