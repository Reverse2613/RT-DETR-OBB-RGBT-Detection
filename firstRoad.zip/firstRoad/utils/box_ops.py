# utils/box_ops.py
import torch

def generate_jittered_boxes(gt_bboxes: torch.Tensor, expand_ratio: float = 1.5, jitter_range: float = 0.1):
    """
    【训练阶段二专用】生成带随机扰动的伪候选框 (Simulated Coarse ROI)
    参数:
        gt_bboxes: 真实的归一化坐标 (B, 4) -> [x1, y1, x2, y2]
    返回:
        jittered_boxes: 扰动+放大后的候选框 (B, 4)
        local_gt_bboxes: 真实框在局部切片中的相对坐标 (B, 4)，用于算 Loss！
    """
    B = gt_bboxes.size(0)
    
    # 1. 计算 GT 的中心点和宽高
    x1, y1, x2, y2 = gt_bboxes[:, 0], gt_bboxes[:, 1], gt_bboxes[:, 2], gt_bboxes[:, 3]
    w = x2 - x1
    h = y2 - y1
    cx = x1 + w / 2
    cy = y1 + h / 2
    
    # 2. 加入随机扰动 (模拟第一阶段的不完美)
    # 生成 -0.1 到 0.1 的随机偏移比例
    dx = (torch.rand(B, device=gt_bboxes.device) * 2 - 1) * jitter_range * w
    dy = (torch.rand(B, device=gt_bboxes.device) * 2 - 1) * jitter_range * h
    
    jittered_cx = cx + dx
    jittered_cy = cy + dy
    
    # 3. 放大候选框 (给第二阶段留下搜索的上下文空间)
    new_w = w * expand_ratio
    new_h = h * expand_ratio
    
    # 4. 计算出伪候选框 (Simulated Coarse Box)
    j_x1 = torch.clamp(jittered_cx - new_w / 2, min=0.0)
    j_y1 = torch.clamp(jittered_cy - new_h / 2, min=0.0)
    j_x2 = torch.clamp(jittered_cx + new_w / 2, max=1.0)
    j_y2 = torch.clamp(jittered_cy + new_h / 2, max=1.0)
    
    jittered_boxes = torch.stack([j_x1, j_y1, j_x2, j_y2], dim=1)
    
    # 5. 【极其关键的数学映射】：计算 GT 框在这个新切片里的“局部归一化坐标”
    # 阶段二预测的就是这个坐标！
    crop_w = j_x2 - j_x1
    crop_h = j_y2 - j_y1
    
    local_x1 = torch.clamp((x1 - j_x1) / crop_w, min=0.0, max=1.0)
    local_y1 = torch.clamp((y1 - j_y1) / crop_h, min=0.0, max=1.0)
    local_x2 = torch.clamp((x2 - j_x1) / crop_w, min=0.0, max=1.0)
    local_y2 = torch.clamp((y2 - j_y1) / crop_h, min=0.0, max=1.0)
    
    local_gt_bboxes = torch.stack([local_x1, local_y1, local_x2, local_y2], dim=1)
    
    return jittered_boxes, local_gt_bboxes