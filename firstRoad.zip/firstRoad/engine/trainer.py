# engine/trainer.py
import torch
from tqdm import tqdm
from utils.logger import logger
from utils.loss import Stage1Loss

class Stage1Trainer:
    """
    阶段一的训练器
    负责联合训练 Stage1MacroNetwork、BERTEncoder 和 TextRouter
    """
    def __init__(self, text_encoder, text_router, stage1_model, dataloader, device, lr=1e-4):
        self.device = device
        self.dataloader = dataloader
        
        # 将模型转移到 GPU 并设置为训练模式
        self.text_encoder = text_encoder.to(device)
        self.text_router = text_router.to(device)
        self.stage1_model = stage1_model.to(device)
        
        self.text_router.train()
        self.stage1_model.train()
        # 注意：text_encoder (BERT) 我们为了省显存，保持 eval 模式，不更新它的底层权重
        self.text_encoder.eval() 

        # 实例化我们刚写的联合损失函数
        self.criterion = Stage1Loss(lambda_distill=0.5)

        # 优化器：联合优化 Router 和 Stage1 网络！
        self.optimizer = torch.optim.AdamW([
            {'params': self.text_router.parameters(), 'lr': lr * 0.1}, # Router 学习率小一点
            {'params': self.stage1_model.parameters(), 'lr': lr}
        ], weight_decay=1e-4)

    def train_epoch(self, epoch):
        logger.info(f"==========  开始训练 Epoch {epoch} ==========")
        total_loss_avg = 0.0
        bbox_loss_avg = 0.0
        sem_loss_avg = 0.0
        
        # 使用 tqdm 进度条，企业级工程必备
        pbar = tqdm(self.dataloader, desc=f"Epoch {epoch}", leave=True)
        
        for batch_idx, batch_data in enumerate(pbar):
            # 1. 数据上 GPU
            img_stage1 = batch_data["img_stage1"].to(self.device)
            semantic_mask = batch_data["semantic_mask"].to(self.device)
            norm_bbox = batch_data["norm_bbox"].to(self.device)
            expressions = batch_data["expression"]
            
            # 2. 前向传播 (Forward)
            self.optimizer.zero_grad() # 梯度清零
            
            with torch.no_grad():
                # BERT 提特征不参与梯度更新，节省算力
                text_feat = self.text_encoder(list(expressions), self.device)
                
            # 三粒度解耦路由
            t_geo, t_rel, t_obj = self.text_router(text_feat)
            
            # 阶段一宏观粗搜
            pred_bbox, pred_semantic = self.stage1_model(img_stage1, t_geo, t_rel)
            
            # 3. 计算联合损失
            loss, l_bbox, l_sem = self.criterion(
                pred_bbox=pred_bbox, 
                target_bbox=norm_bbox, 
                pred_semantic=pred_semantic, 
                target_semantic=semantic_mask
            )
            
            # 4. 反向传播与权重更新 (Backward & Step)
            loss.backward()
            
            # 梯度裁剪 (防止梯度爆炸，顶级模型的安全锁)
            torch.nn.utils.clip_grad_norm_(self.stage1_model.parameters(), max_norm=1.0)
            
            self.optimizer.step()
            
            # 5. 记录日志
            total_loss_avg += loss.item()
            bbox_loss_avg += l_bbox.item()
            sem_loss_avg += l_sem.item()
            
            # 实时更新进度条后缀
            pbar.set_postfix({
                'Loss': f"{loss.item():.4f}", 
                'L_box': f"{l_bbox.item():.4f}",
                'L_sem': f"{l_sem.item():.4f}"
            })
            
        # 计算 Epoch 平均 Loss
        num_batches = len(self.dataloader)
        logger.info(f"[Epoch {epoch} 总结] Total Loss: {total_loss_avg/num_batches:.4f} | Bbox Loss: {bbox_loss_avg/num_batches:.4f} | Semantic Loss: {sem_loss_avg/num_batches:.4f}")