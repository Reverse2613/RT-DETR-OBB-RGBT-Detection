# engine/trainer_stage2.py
import torch
import torch.nn.functional as F
from tqdm import tqdm
from utils.logger import logger
from utils.cropper import DynamicHighResCropper
from utils.box_ops import generate_jittered_boxes

# 为了安全，这里我们手写一个极简的 L1 + IoU Loss，避免前面的负数 Bug
def simple_bbox_loss(pred, target):
    l1_loss = F.l1_loss(pred, target, reduction='mean')
    
    # 强制纠正初期网络随机输出的反转框 (x1 > x2 的情况)
    pred_x1 = torch.min(pred[:, 0], pred[:, 2])
    pred_y1 = torch.min(pred[:, 1], pred[:, 3])
    pred_x2 = torch.max(pred[:, 0], pred[:, 2])
    pred_y2 = torch.max(pred[:, 1], pred[:, 3])
    pred_valid = torch.stack([pred_x1, pred_y1, pred_x2, pred_y2], dim=1)

    # 简易版 IoU (使用纠正后的有效框)
    lt = torch.max(pred_valid[:, :2], target[:, :2])
    rb = torch.min(pred_valid[:, 2:], target[:, 2:])
    wh = (rb - lt).clamp(min=0)
    inter = wh[:, 0] * wh[:, 1]
    
    area_pred = (pred_valid[:, 2] - pred_valid[:, 0]) * (pred_valid[:, 3] - pred_valid[:, 1])
    area_targ = (target[:, 2] - target[:, 0]) * (target[:, 3] - target[:, 1])
    union = area_pred + area_targ - inter
    
    iou = (inter / union.clamp(min=1e-6)).mean()
    
    return l1_loss + (1 - iou), l1_loss, iou

class Stage2Trainer:
    """
    阶段二专属训练器
    只在高清切片上找目标，并反馈更新 Text Router 的微观解耦能力！
    """
    def __init__(self, text_encoder, text_router, stage2_model, dataloader, device, lr=1e-4):
        self.device = device
        self.dataloader = dataloader
        self.cropper = DynamicHighResCropper(target_crop_size=256, expand_ratio=1.5)
        
        self.text_encoder = text_encoder.to(device)
        self.text_router = text_router.to(device)
        self.stage2_model = stage2_model.to(device)
        
        # 激活模型
        self.text_encoder.eval()
        self.text_router.train() # 解冻 Router！让它学习高清文本特征！
        self.stage2_model.train()

        # 联合优化：Stage2 网络 + Text Router (解决特征不对齐难题)
        self.optimizer = torch.optim.AdamW([
            {'params': self.text_router.parameters(), 'lr': lr * 0.1}, 
            {'params': self.stage2_model.parameters(), 'lr': lr}
        ], weight_decay=1e-4)

    def train_epoch(self, epoch):
        logger.info(f"========== 开始阶段二精搜训练 Epoch {epoch} ==========")
        total_loss_avg, l1_avg, iou_avg = 0.0, 0.0, 0.0
        pbar = tqdm(self.dataloader, desc=f"Stage2 Epoch {epoch}", leave=True)
        
        for batch_data in pbar:
            norm_bbox = batch_data["norm_bbox"].to(self.device)
            expressions = batch_data["expression"]
            orig_paths = batch_data["orig_img_path"]
            
            self.optimizer.zero_grad()
            
            # 1. 文本特征提取与三粒度解耦
            with torch.no_grad():
                text_feat = self.text_encoder(list(expressions), self.device)
            t_geo, t_rel, t_obj = self.text_router(text_feat)
            
            # 2. 核心魔法：生成伪粗略框，并计算出目标在切片里的相对真实坐标！
            #jittered_boxes, local_gt_bboxes = generate_jittered_boxes(norm_bbox)
            # 【神级修复】：在敏捷验证过拟合阶段，必须关闭随机扰动 (jitter_range=0.0)，让靶子固定！
            # 等到我们后续真正去跑那 100万 全量数据时，再把它改回默认的 0.1
            jittered_boxes, local_gt_bboxes = generate_jittered_boxes(norm_bbox, jitter_range=0.0)
            
            # 3. 动态原图高清裁切
            crop_tensors = self.cropper.process_batch(orig_paths, jittered_boxes, self.device)
            
            # 4. 阶段二精细搜索 (输入: 高清图 + 属性词 + 关系词)
            pred_local_bbox = self.stage2_model(crop_tensors, t_obj, t_rel)
            
            # 5. 计算 Loss (预测相对坐标 VS 真实相对坐标)
            loss, l1, iou = simple_bbox_loss(pred_local_bbox, local_gt_bboxes)
            
            loss.backward()
            torch.nn.utils.clip_grad_norm_(self.stage2_model.parameters(), max_norm=1.0)
            self.optimizer.step()
            
            # 日志更新
            total_loss_avg += loss.item()
            l1_avg += l1.item()
            iou_avg += iou.item()
            pbar.set_postfix({'Loss': f"{loss.item():.4f}", 'IoU': f"{iou.item():.4f}"})
            
        num_batches = len(self.dataloader)
        logger.info(f"[Epoch {epoch} 总结] Loss: {total_loss_avg/num_batches:.4f} | IoU: {iou_avg/num_batches:.4f}")