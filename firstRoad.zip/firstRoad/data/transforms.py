# data/transforms.py
import torch
import torchvision.transforms.functional as F
from PIL import Image
import numpy as np

class Stage1Transforms:
    """
    专门为 Stage 1 (宏观粗搜) 设计的数据变换类。
    负责将任意大小的无人机图像和 Mask，安全地统一缩放为低分辨率固定尺寸。
    """
    def __init__(self, target_size: int = 512):
        self.target_size = (target_size, target_size)
        
        # ImageNet 标准归一化参数，用于 RGB 图像提取特征
        self.mean =[0.485, 0.456, 0.406]
        self.std =[0.229, 0.224, 0.225]

    def __call__(self, image: Image.Image, mask: np.ndarray, bbox: list):
        """
        参数:
            image: PIL RGB 图像
            mask: 2D numpy 数组 (类别 ID)
            bbox:[x_min, y_min, x_max, y_max] 绝对坐标
        返回:
            img_tensor: 归一化后的 RGB 张量 (3, H, W)
            mask_tensor: 缩放后的 Mask 张量 (H, W)
            norm_bbox: 归一化的 BBox (4,) 范围在 0~1 之间
        """
        orig_w, orig_h = image.size
        
        # 1. 处理 RGB 图像: 双线性插值 (Bilinear)
        img_tensor = F.to_tensor(image)  # 自动转 0~1
        img_tensor = F.resize(img_tensor, self.target_size, interpolation=F.InterpolationMode.BILINEAR)
        img_tensor = F.normalize(img_tensor, mean=self.mean, std=self.std)
        
        # 2. 处理语义 Mask: 必须是最近邻插值 (Nearest) 以防类别数值被破坏！
        mask_tensor = torch.from_numpy(mask).unsqueeze(0).float() # (1, H, W)
        mask_tensor = F.resize(mask_tensor, self.target_size, interpolation=F.InterpolationMode.NEAREST)
        mask_tensor = mask_tensor.squeeze(0).long() # 转回整数 (H, W)
        
        # 3. 处理 Bounding Box: 转换为 0~1 之间的相对坐标 (解决尺寸不统一问题)
        x_min, y_min, x_max, y_max = bbox
        norm_bbox = torch.tensor([
            x_min / orig_w,
            y_min / orig_h,
            x_max / orig_w,
            y_max / orig_h
        ], dtype=torch.float32)
        
        # 极度安全的裁切，防止框超出图片边界
        norm_bbox = torch.clamp(norm_bbox, min=0.0, max=1.0)
        
        return img_tensor, mask_tensor, norm_bbox