# data/dataset.py
import os
import cv2
import numpy as np
from PIL import Image
from torch.utils.data import Dataset
from pathlib import Path
import torch

from config import CFG
from utils.logger import logger
from data.transforms import Stage1Transforms

class SkyFindDataset(Dataset):
    """
     SkyFind 数据集加载器。
    具备自动过滤无效框、跳过破损图片、解耦原图与低分辨率图的功能。
    """
    def __init__(self, annotations: list, image_dir: Path, mask_dir: Path, target_size: int = 512):
        self.image_dir = image_dir
        self.mask_dir = mask_dir
        self.transforms = Stage1Transforms(target_size=target_size)
        
        # 数据清洗：在初始化时过滤掉脏数据，保证训练不中断
        self.valid_data = self._clean_data(annotations)
        logger.info(f"数据集清洗完毕，保留了 {len(self.valid_data)} 条高质量记录。")

    def _clean_data(self, annotations: list) -> list:
        """自动清洗脏数据：过滤掉没有图、没有 Mask 或框面积为 0 的异常数据"""
        cleaned =[]
        for ann in annotations:
            img_name = ann.get("fileName", "")
            bbox = ann.get("bbox",[]) # 格式通常为 [x_min, y_min, x_max, y_max]
            expr = ann.get("expression", "")
            
            img_path = self.image_dir / img_name
            mask_path = self.mask_dir / f"mask_{img_name.replace('.jpg', '.png')}"
            
            # 基础规则过滤
            if not img_name or not expr or len(bbox) != 4:
                continue
            
            # 判断框的合法性 (防止长宽为 0 或负数导致模型 NaN)
            if bbox[2] <= bbox[0] or bbox[3] <= bbox[1]:
                continue
                
            cleaned.append({
                "img_name": img_name,
                "img_path": str(img_path),
                "mask_path": str(mask_path),
                "bbox": bbox,
                "expression": expr
            })
            
        return cleaned

    def __len__(self):
        return len(self.valid_data)

    def __getitem__(self, idx):
        """
        每次读取只返回阶段一需要的低分辨率张量，以及原图的路径。
        极其节省内存！
        """
        data_item = self.valid_data[idx]
        
        # 1. 安全读取 RGB 图片
        try:
            image = Image.open(data_item["img_path"]).convert("RGB")
            orig_w, orig_h = image.size
        except Exception as e:
            # 工程实践：遇到坏图不抛出崩溃，而是返回索引 0 的安全数据 (容错机制)
            logger.warning(f"无法读取图片 {data_item['img_path']}, 触发安全容错。")
            return self.__getitem__(0)
            
        # 2. 安全读取 Mask (如果你还没生成全部的 Mask，这里会造一张全背景的安全伪图)
        mask_path = data_item["mask_path"]
        if os.path.exists(mask_path):
            # 注意：之前我们保存的是单通道 np 数组，cv2.IMREAD_GRAYSCALE 可以读出类别ID
            mask = cv2.imread(mask_path, cv2.IMREAD_GRAYSCALE) 
        else:
            # 如果没找到 Mask，填充 0 (背景)，保证代码不会死锁
            mask = np.zeros((orig_h, orig_w), dtype=np.uint8)
            
        # 3. 经过 Transforms 进行严格处理
        img_tensor, mask_tensor, norm_bbox = self.transforms(image, mask, data_item["bbox"])
        
        # 4. 返回一个解耦度极高的字典
        return {
            "img_stage1": img_tensor,            # (3, 512, 512) 供阶段一粗搜
            "semantic_mask": mask_tensor,        # (512, 512)    供阶段一隐式蒸馏
            "expression": data_item["expression"],# 字符串文本   供 Text Router
            "norm_bbox": norm_bbox,              # (4,) 0~1坐标  供阶段一算 Loss
            "orig_img_path": data_item["img_path"],# 字符串       供阶段二随时截取 4K 原图！
            "orig_size": torch.tensor([orig_w, orig_h])
        }