# data/skyfind_parser.py  专门负责安全解析 SkyFind 数据集 JSON 标注文件的类
import json
from pathlib import Path
from typing import List, Dict, Any
from utils.logger import logger

class SkyFindParser:
    """
    专门负责安全解析 SkyFind 数据集 JSON 标注文件的类。
    """
    def __init__(self, json_path: Path):
        self.json_path = json_path
        self.data = []
        
    def load_data(self) -> List[Dict[str, Any]]:
        """
        安全加载 JSON 文件，并做基础的完整性校验。
        """
        logger.info(f"开始加载 SkyFind 标注文件: {self.json_path}")
        if not self.json_path.exists():
            raise FileNotFoundError(f"[!] 找不到标注文件: {self.json_path}")
            
        try:
            with open(self.json_path, 'r', encoding='utf-8') as f:
                self.data = json.load(f)
            logger.info(f"成功加载，共包含 {len(self.data)} 条标注记录。")
            
            
            # 打印第一条数据，分析数据结构
            if len(self.data) > 0:
                logger.info(f"数据探针 -> 第一条标注结构预览: {list(self.data[0].keys())}")
                
            return self.data
            
        except json.JSONDecodeError as e:
            logger.error(f"JSON 文件解析失败，可能文件已损坏: {e}")
            raise e
        except Exception as e:
            logger.error(f"发生未知错误: {e}")
            raise e