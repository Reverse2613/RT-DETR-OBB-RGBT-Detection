# models/stage2_micro.py
import torch
import torch.nn as nn
import torchvision.models as models

class Stage2MicroNetwork(nn.Module):
    def __init__(self, hidden_dim: int = 256):
        super().__init__()
        self.hidden_dim = hidden_dim
        
        # 1. 轻量级视觉主干 (ResNet-18)
        resnet = models.resnet18(weights=models.ResNet18_Weights.IMAGENET1K_V1)
        self.backbone = nn.Sequential(*list(resnet.children())[:-2])
        self.vis_proj = nn.Conv2d(512, hidden_dim, kernel_size=1)
        
        # 2. 跨模态注意力融合
        self.cross_attn = nn.MultiheadAttention(embed_dim=hidden_dim, num_heads=8, batch_first=True)
        
        # ==============================================================
        # 3. 【神级修复】保留空间几何特征的卷积预测头 (Spatial-Aware Head)
        # ==============================================================
        self.spatial_conv = nn.Sequential(
            nn.Conv2d(hidden_dim, 64, kernel_size=3, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),
            nn.Conv2d(64, 16, kernel_size=3, padding=1),
            nn.BatchNorm2d(16),
            nn.ReLU(inplace=True)
        )
        
        # 展平后进行坐标回归 (16个通道 * 8 * 8 特征图大小 = 1024)
        self.bbox_head = nn.Sequential(
            nn.Flatten(),
            nn.Linear(16 * 8 * 8, 128),
            nn.ReLU(inplace=True),
            nn.Linear(128, 4),
            nn.Sigmoid() 
        )

    def forward(self, crop_images: torch.Tensor, t_obj: torch.Tensor, t_rel: torch.Tensor):
        B = crop_images.size(0)
        
        # 提取高清局部视觉特征
        v_feat = self.backbone(crop_images)  # (B, 512, 8, 8)
        v_feat = self.vis_proj(v_feat)       # (B, 256, 8, 8)
        
        # 展平准备 Attention
        v_feat_flat = v_feat.view(B, self.hidden_dim, -1).permute(0, 2, 1) # (B, 64, 256)
        text_cond = torch.cat([t_obj.unsqueeze(1), t_rel.unsqueeze(1)], dim=1) # (B, 2, 256)
        
        # 注意力融合：每个像素独立向文本提问
        fused_feat, _ = self.cross_attn(query=v_feat_flat, key=text_cond, value=text_cond)
        
        # ==============================================================
        # 4. 【核心魔法】将融合后的特征重新折叠回 2D 空间矩阵！
        # ==============================================================
        # fused_feat 是 (B, 64, 256) -> 转回 (B, 256, 8, 8)
        fused_spatial = fused_feat.permute(0, 2, 1).view(B, self.hidden_dim, 8, 8)
        
        # 通过空间卷积层，网络现在清晰地知道那个“红色轿车”在 8x8 网格的哪个角！
        spatial_out = self.spatial_conv(fused_spatial)
        
        # 最终精准回归
        pred_local_bbox = self.bbox_head(spatial_out) 
        
        return pred_local_bbox