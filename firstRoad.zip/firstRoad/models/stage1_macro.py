# models/stage1_macro.py
import torch
import torch.nn as nn
import torchvision.models as models
import torch.nn.functional as F

class Stage1MacroNetwork(nn.Module):
    """
    Eagle-REC 阶段一：宏观拓扑隐式蒸馏与粗略搜索网络
    """
    def __init__(self, hidden_dim: int = 256, num_topology_classes: int = 15):
        super().__init__()
        self.hidden_dim = hidden_dim
        
        # ==========================================
        # 1. 视觉主干网络 (Visual Backbone: ResNet-50)
        # ==========================================
        # 使用更新的 weights API (旧的 pretrained=True 已被弃用)
        resnet = models.resnet50(weights=models.ResNet50_Weights.IMAGENET1K_V2)
        # 移除最后的全连接层和池化层，我们只需要特征图
        self.backbone = nn.Sequential(*list(resnet.children())[:-2])
        
        # 降维卷积：将 ResNet 输出的 2048 维特征通道降到 256 维
        self.vis_proj = nn.Conv2d(2048, hidden_dim, kernel_size=1)
        
        # ==========================================
        # 2. 跨模态注意力融合 (Cross-Modal Fusion)
        # 视觉作为 Query，文本作为 Key 和 Value
        # ==========================================
        self.cross_attn = nn.MultiheadAttention(embed_dim=hidden_dim, num_heads=8, batch_first=True)
        
        # ==========================================
        # 3. 创新分支 A：宏观拓扑蒸馏解码器 (Auxiliary Distillation Head)
        # 强制网络学习地理空间分布
        # ==========================================
        self.semantic_head = nn.Sequential(
            # 输入特征图大小是 512 / 32 = 16x16
            nn.ConvTranspose2d(hidden_dim, 128, kernel_size=4, stride=2, padding=1), # 32x32
            nn.ReLU(inplace=True),
            nn.ConvTranspose2d(128, 64, kernel_size=4, stride=2, padding=1),  # 64x64
            nn.ReLU(inplace=True),
            nn.ConvTranspose2d(64, 32, kernel_size=4, stride=2, padding=1),   # 128x128
            nn.ReLU(inplace=True),
            nn.ConvTranspose2d(32, 16, kernel_size=4, stride=2, padding=1),   # 256x256
            nn.ReLU(inplace=True),
            nn.ConvTranspose2d(16, num_topology_classes, kernel_size=4, stride=2, padding=1) # 512x512
            # 最终输出: (Batch, num_classes, 512, 512)
        )
        
        # ==========================================
        # 4. 创新分支 B：粗略候选框回归器 (Coarse BBox Head)
        # ==========================================
        self.bbox_head = nn.Sequential(
            nn.Linear(hidden_dim, 128),
            nn.ReLU(inplace=True),
            nn.Linear(128, 64),
            nn.ReLU(inplace=True),
            nn.Linear(64, 4),
            nn.Sigmoid() # 保证输出的坐标永远在 0~1 之间！(极度安全)
        )

    def forward(self, images: torch.Tensor, t_geo: torch.Tensor, t_rel: torch.Tensor):
        """
        参数:
            images: (B, 3, 512, 512)
            t_geo: 文本解耦的宏观地理特征 (B, 256)
            t_rel: 文本解耦的相对方位特征 (B, 256)
        """
        B = images.size(0)
        
        # 1. 提取视觉特征
        v_feat = self.backbone(images)  # (B, 2048, 16, 16)
        v_feat = self.vis_proj(v_feat)  # (B, 256, 16, 16)
        
        # 2. 蒸馏分支流出 (保持 2D 空间结构)
        # 这一步极其关键：它是推理时可拔插的！
        pred_semantic = self.semantic_head(v_feat) # (B, num_classes, 512, 512)
        
        # 3. 为注意力机制做准备：展平空间维度
        v_feat_flat = v_feat.view(B, self.hidden_dim, -1).permute(0, 2, 1) # (B, 256, 256) -> Seq_len=256
        
        # 将文本特征拼接，作为注意力引导的条件 (Condition)
        # t_geo 和 t_rel 组合，指导网络去哪里找目标
        text_cond = torch.cat([t_geo.unsqueeze(1), t_rel.unsqueeze(1)], dim=1) # (B, 2, 256)
        
        # 4. 跨模态注意力融合
        # 视觉去向文本“查询(Query)”，获取重点关注区域
        fused_feat, attn_weights = self.cross_attn(
            query=v_feat_flat, 
            key=text_cond, 
            value=text_cond
        )
        
        # 5. 回归粗略边界框
        # 对融合后的所有像素特征取平均 (Global Average Pooling)
        global_feat = fused_feat.mean(dim=1) # (B, 256)
        pred_bbox = self.bbox_head(global_feat) # (B, 4)
        
        return pred_bbox, pred_semantic