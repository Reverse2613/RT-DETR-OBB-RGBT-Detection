# models/text_router.py
import torch
import torch.nn as nn
import torch.nn.functional as F

class TriGranularityTextRouter(nn.Module):
    """
    Eagle-REC 核心创新模块：三粒度文本解耦路由器 (Tri-Granularity Text Router)
    
    作用：
    将经过 BERT 等语言模型提取的一维全局文本特征，智能拆解为三个正交的语义空间：
    1. T_geo (地理拓扑): 关注 "马路", "十字路口", "草地" 等宏观概念，用于阶段一粗搜。
    2. T_rel (空间方位): 关注 "左侧", "靠近", "中间" 等相对关系，贯穿两阶段。
    3. T_obj (微观属性): 关注 "红色", "轿车", "戴帽子" 等细节特征，用于阶段二精搜。
    """
    def __init__(self, hidden_dim: int = 256):
        super().__init__()
        self.hidden_dim = hidden_dim
        
        # ----------------------------------------------------------------
        # 1. 特征投影层 (Feature Projection)
        # 我们使用带有 LayerNorm 和 ReLU 的浅层 MLP，保证梯度稳定且参数量极小
        # ----------------------------------------------------------------
        
        # 提取地理特征的网络分支
        self.geo_proj = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.ReLU(inplace=True),
            nn.Linear(hidden_dim, hidden_dim)
        )
        
        # 提取关系/方位特征的网络分支
        self.rel_proj = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.ReLU(inplace=True),
            nn.Linear(hidden_dim, hidden_dim)
        )
        
        # 提取目标微观属性特征的网络分支
        self.obj_proj = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.ReLU(inplace=True),
            nn.Linear(hidden_dim, hidden_dim)
        )

        # ----------------------------------------------------------------
        # 2. 动态注意力路由门控 (Dynamic Routing Gate)
        # 决定这句话里，地理、方位、属性 这三个维度各占多大的比重
        # ----------------------------------------------------------------
        self.routing_gate = nn.Linear(hidden_dim, 3)

    def forward(self, text_features: torch.Tensor):
        """
        前向传播计算
        参数:
            text_features: 经过 BERT 提取的全局文本特征，形状为 (Batch_Size, hidden_dim)
        返回:
            t_geo, t_rel, t_obj (解耦且经过自适应加权后的特征)
        """
        # 安全性防御机制：检查输入维度
        if text_features.dim() != 2 or text_features.shape[1] != self.hidden_dim:
            raise ValueError(f"[!] Text Router 输入维度错误！期望 (Batch, {self.hidden_dim})，实际收到 {text_features.shape}")

        # 计算路由注意力门控值 (使用 softmax 保证三个权重之和为 1.0)
        # gates shape: (Batch_Size, 3)
        gates = F.softmax(self.routing_gate(text_features), dim=-1)
        
        # 将原始特征分别投影到三个正交的子空间中
        base_geo = self.geo_proj(text_features)  # (Batch_Size, hidden_dim)
        base_rel = self.rel_proj(text_features)
        base_obj = self.obj_proj(text_features)
        
        # 核心：将门控权重与投影特征相乘，实现特征的“自适应抑制或激活”
        # 假设句子里没提地理词（比如只有“红车”），gates[:, 0] 会趋近于 0，从而安全地抑制 t_geo 产生干扰噪音
        t_geo = base_geo * gates[:, 0].unsqueeze(-1)
        t_rel = base_rel * gates[:, 1].unsqueeze(-1)
        t_obj = base_obj * gates[:, 2].unsqueeze(-1)
        
        return t_geo, t_rel, t_obj