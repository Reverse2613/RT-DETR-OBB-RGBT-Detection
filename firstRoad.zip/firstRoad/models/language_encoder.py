# models/language_encoder.py
import torch
import torch.nn as nn
from transformers import AutoModel, AutoTokenizer
from utils.logger import logger

class BERTEncoder(nn.Module):
    """
    BERT 文本特征提取器
    负责将自然语言描述转换为高维密集向量 (Dense Vector)
    """
    def __init__(self, hidden_dim: int = 256, model_name: str = "bert-base-uncased"):
        super().__init__()
        logger.info(f"Loading Text Encoder: {model_name}...")
        
        # 加载 HuggingFace 预训练模型
        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        self.bert = AutoModel.from_pretrained(model_name)
        
        # 冻结 BERT 的前几层以节省显存并加快训练 (迁移学习的标准操作)
        for param in self.bert.embeddings.parameters():
            param.requires_grad = False
        for param in self.bert.encoder.layer[:8].parameters():
            param.requires_grad = False
            
        # 维度投影层：将 BERT 默认的 768 维降维到我们设定的 hidden_dim (256)
        self.proj = nn.Sequential(
            nn.Linear(self.bert.config.hidden_size, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.ReLU(inplace=True)
        )

    def forward(self, text_list: list, device: torch.device):
        """
        参数:
            text_list: 包含 batch_size 个文本描述的列表
        返回:
            torch.Tensor: 形状为 (Batch, hidden_dim) 的文本特征
        """
        # 安全的动态 Padding 和截断
        inputs = self.tokenizer(
            text_list, 
            padding=True, 
            truncation=True, 
            max_length=60, # 无人机的指令一般较短，60足够了
            return_tensors="pt"
        ).to(device)

        # 提取特征
        outputs = self.bert(**inputs)
        
        # 我们使用 [CLS] token 的输出作为整句话的全局特征表示
        cls_feat = outputs.last_hidden_state[:, 0, :] # Shape: (Batch, 768)
        
        # 降维投影
        final_feat = self.proj(cls_feat) # Shape: (Batch, 256)
        
        return final_feat