# test_stage2.py
import torch
import os
os.environ["TOKENIZERS_PARALLELISM"] = "false"

from config import CFG
from utils.logger import logger
from data.skyfind_parser import SkyFindParser
from data.dataset import SkyFindDataset
from torch.utils.data import DataLoader
from models.language_encoder import BERTEncoder
from models.text_router import TriGranularityTextRouter
from models.stage2_micro import Stage2MicroNetwork
from engine.trainer_stage2 import Stage2Trainer

def test_stage2_training():
    logger.info("=== 启动 Eagle-REC 阶段二(精搜)敏捷验证 ===")
    
    # 1. 数据准备 (和阶段一一样，我们就跑前 50 张图)
    parser = SkyFindParser(json_path=CFG.VAL_JSON)
    dataset = SkyFindDataset(
        annotations=parser.load_data()[:50], 
        image_dir=CFG.IMAGE_DIR, 
        mask_dir=CFG.MASK_OUT_DIR,
        target_size=CFG.stage1_input_size
    )
    dataloader = DataLoader(dataset, batch_size=CFG.batch_size, shuffle=False, drop_last=True)
    
    # 2. 加载模型
    text_encoder = BERTEncoder(hidden_dim=256).to(CFG.DEVICE)
    text_router = TriGranularityTextRouter(hidden_dim=256).to(CFG.DEVICE)
    stage2_model = Stage2MicroNetwork(hidden_dim=256).to(CFG.DEVICE)
    
    # 3. 实例化我们刚写的 Stage2 训练器
    trainer = Stage2Trainer(
        text_encoder=text_encoder,
        text_router=text_router,
        stage2_model=stage2_model,
        dataloader=dataloader,
        device=CFG.DEVICE
    )
    
    # 4. 狂飙训练 50 个 Epoch
    logger.info("开始进行阶段二“原图切片+精搜”的单批次过拟合验证...")
    for epoch in range(1, 51):
        trainer.train_epoch(epoch)

if __name__ == "__main__":
    test_stage2_training()