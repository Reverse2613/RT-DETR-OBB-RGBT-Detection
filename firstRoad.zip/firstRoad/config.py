# config.py   全局配置中心
import os
from pathlib import Path
from dataclasses import dataclass

@dataclass
class ProjectConfig:
    # ==========================================
    # 1. 基础路径设定
    # ==========================================
    DATA_ROOT: Path = Path("/root/group_data")  
    
    # 细分路径
    IMAGE_DIR: Path = DATA_ROOT / "SkyFind-images" 
    
    VAL_JSON: Path = DATA_ROOT / "Val.json"
    TRAIN_JSON: Path = DATA_ROOT / "Train.json"
    
    # 生成的伪标签(Mask)的保存目录
    MASK_OUT_DIR: Path = Path("/root/private_data/SkyFindMask")
    
    # ==========================================
    # 2. 硬件与外部模型配置
    # ==========================================
    DEVICE: str = "cuda"
    SEG_MODEL_ID: str = "shi-labs/oneformer_ade20k_swin_large"
    
    # ==========================================
    # 3. 网络核心超参数
    # ==========================================
    stage1_input_size: int = 512  # 第一阶段为了省显存的极度压缩尺寸
    hidden_dim: int = 256         # 多模态特征融合的隐藏层维度
    batch_size: int = 32           #  48G L20 卡,可以开到 16 或 32
    
    num_topology_classes: int = 150  # 完美适配 ADE20K 的原生类别
    
    def __post_init__(self):
        """安全机制：初始化配置时，自动创建必要的输出文件夹"""
        self.MASK_OUT_DIR.mkdir(parents=True, exist_ok=True)

# 实例化全局单例配置
CFG = ProjectConfig()