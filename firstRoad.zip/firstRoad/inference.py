# inference.py
import torch
import cv2
import numpy as np
from PIL import Image
from config import CFG
from utils.logger import logger
from models.language_encoder import BERTEncoder
from models.text_router import TriGranularityTextRouter
from models.stage1_macro import Stage1MacroNetwork
from models.stage2_micro import Stage2MicroNetwork
from data.transforms import Stage1Transforms
from utils.cropper import DynamicHighResCropper

def inference_single_image(img_path: str, expression: str):
    logger.info(f"===  Eagle-REC 启动全链路推理 ===")
    logger.info(f"任务指令: '{expression}'")
    
    device = CFG.DEVICE
    
    # 1. 模拟加载我们训练好的模型权重 (因为你跑了单批次过拟合，模型已经有了记忆！)
    text_encoder = BERTEncoder().to(device).eval()
    text_router = TriGranularityTextRouter().to(device).eval()
    stage1 = Stage1MacroNetwork(num_topology_classes=150).to(device).eval()
    stage2 = Stage2MicroNetwork().to(device).eval()
    
    # 加载你昨天跑完保存的 Stage1 权重 (假设你在 test_stage1 里保存了)
    #stage1.load_state_dict(torch.load("eagle_rec_stage1_epoch_50.pth")['stage1_state_dict'])
    # text_router.load_state_dict(...) 
    # (今天为了跑通代码逻辑，我们先用初始权重走一遍流程)
    
    # 2. 读取原图和数据预处理
    orig_img = Image.open(img_path).convert("RGB")
    orig_w, orig_h = orig_img.size
    logger.info(f"读取 UAV 原图成功，尺寸: {orig_w} x {orig_h}")
    
    transforms = Stage1Transforms(target_size=512)

    # 推理时没有 GT mask 和 bbox，随便传空的进去即可
    dummy_mask = np.zeros((orig_h, orig_w), dtype=np.uint8)
    dummy_bbox =[0, 0, 1, 1]
    
    img_stage1, _, _ = transforms(orig_img, dummy_mask, dummy_bbox)
    img_stage1 = img_stage1.unsqueeze(0).to(device) # (1, 3, 512, 512)
    
    # 3. 语言特征解耦
    with torch.no_grad():
        text_feat = text_encoder([expression], device)
        t_geo, t_rel, t_obj = text_router(text_feat)
    
    # 4. Stage 1 宏观粗搜
    with torch.no_grad():
        coarse_bbox, _ = stage1(img_stage1, t_geo, t_rel) # coarse_bbox: (1, 4) 归一化
        
    logger.info(f"Stage 1 粗搜归一化坐标: {coarse_bbox[0].cpu().numpy()}")
    
    # 5. 回原图裁剪高清块
    cropper = DynamicHighResCropper(target_crop_size=256, expand_ratio=1.5)
    # cropper 需要保存切片在原图中的绝对坐标，我们这里手动算一下！
    x1 = (coarse_bbox[0, 0] * orig_w).item()
    y1 = (coarse_bbox[0, 1] * orig_h).item()
    x2 = (coarse_bbox[0, 2] * orig_w).item()
    y2 = (coarse_bbox[0, 3] * orig_h).item()
    
    bw, bh = x2 - x1, y2 - y1
    cx, cy = x1 + bw / 2, y1 + bh / 2
    new_bw, new_bh = bw * 1.5, bh * 1.5
    
    crop_x1 = max(0, cx - new_bw / 2)
    crop_y1 = max(0, cy - new_bh / 2)
    crop_x2 = min(orig_w, cx + new_bw / 2)
    crop_y2 = min(orig_h, cy + new_bh / 2)
    
    crop_w_actual = crop_x2 - crop_x1
    crop_h_actual = crop_y2 - crop_y1
    
    # 调 Cropper 拿高清张量
    crop_tensor = cropper.process_batch([img_path], coarse_bbox, device) # (1, 3, 256, 256)
    
    # 6. Stage 2 微观精搜
    with torch.no_grad():
        local_pred_bbox = stage2(crop_tensor, t_obj, t_rel) # (1, 4) 局部归一化
    
    # 7. 终极奥义：局部坐标 -> 原图绝对坐标数学逆映射！
    local_x1 = local_pred_bbox[0, 0].item()
    local_y1 = local_pred_bbox[0, 1].item()
    local_x2 = local_pred_bbox[0, 2].item()
    local_y2 = local_pred_bbox[0, 3].item()
    
    final_abs_x1 = int(crop_x1 + local_x1 * crop_w_actual)
    final_abs_y1 = int(crop_y1 + local_y1 * crop_h_actual)
    final_abs_x2 = int(crop_x1 + local_x2 * crop_w_actual)
    final_abs_y2 = int(crop_y1 + local_y2 * crop_h_actual)
    
    logger.info(f" 终极预测绝对坐标:[{final_abs_x1}, {final_abs_y1}, {final_abs_x2}, {final_abs_y2}]")
    
    # 8. 可视化保存结果
    img_cv2 = cv2.imread(img_path)
    # 画第一阶段的黄色大框
    cv2.rectangle(img_cv2, (int(crop_x1), int(crop_y1)), (int(crop_x2), int(crop_y2)), (0, 255, 255), 2)
    # 画第二阶段的红色精细框
    cv2.rectangle(img_cv2, (final_abs_x1, final_abs_y1), (final_abs_x2, final_abs_y2), (0, 0, 255), 3)
    
    out_path = "inference_result.jpg"
    cv2.imwrite(out_path, img_cv2)
    logger.info(f"结果图片已保存至: {out_path}，去看看画出的框吧！")

if __name__ == "__main__":
    # 请传入一张真实的无人机图片和它对应的句子
    test_img = f"{CFG.IMAGE_DIR}/UAVDT_764.jpg" 
    test_expr = "The white car parked near the intersection."
    inference_single_image(test_img, test_expr)