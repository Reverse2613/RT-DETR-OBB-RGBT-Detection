# train_stage1_full.py
import torch
import os
os.environ["TOKENIZERS_PARALLELISM"] = "false"

from config import CFG
from utils.logger import logger
from data.skyfind_parser import SkyFindParser
from data.dataset import SkyFindDataset
from torch.utils.data import DataLoader
from models.language_encoder import BERTEncoder
from models.text_router import TriGranularityTextRouter
from models.stage1_macro import Stage1MacroNetwork
from engine.trainer import Stage1Trainer

def main():
    logger.info("===  启动 Eagle-REC 阶段一 全量正式训练 ===")
    
    # 1. 挂载 Train (训练集) 的 Json 
    # 如果你的全量数据集里叫 Train.json，请在 config.py 里配置好路径
    parser = SkyFindParser(json_path=CFG.TRAIN_JSON) 
    annotations = parser.load_data()
    
    dataset = SkyFindDataset(
        annotations=annotations, # 全量数据！
        image_dir=CFG.IMAGE_DIR, 
        mask_dir=CFG.MASK_OUT_DIR,
        target_size=CFG.stage1_input_size
    )
    
    # 因为是全量训练，必须打开 shuffle=True！
    dataloader = DataLoader(dataset, batch_size=CFG.batch_size, shuffle=True, drop_last=True, num_workers=8)
    
    # 2. 实例化模型
    text_encoder = BERTEncoder(hidden_dim=CFG.hidden_dim).to(CFG.DEVICE)
    text_router = TriGranularityTextRouter(hidden_dim=CFG.hidden_dim).to(CFG.DEVICE)
    stage1_model = Stage1MacroNetwork(hidden_dim=CFG.hidden_dim, num_topology_classes=150).to(CFG.DEVICE)
    
    trainer = Stage1Trainer(
        text_encoder=text_encoder,
        text_router=text_router,
        stage1_model=stage1_model,
        dataloader=dataloader,
        device=CFG.DEVICE,
        lr=1e-4
    )
    
    # 3. 开启史诗级训练循环 (通常全量数据跑 20-30 个 Epoch 就够了)
    num_epochs = 20
    os.makedirs("checkpoints", exist_ok=True)
    
    for epoch in range(1, num_epochs + 1):
        trainer.train_epoch(epoch)
        
        # 每隔 2 个 Epoch 保存一次权重
        if epoch % 2 == 0 or epoch == num_epochs:
            save_path = f"checkpoints/eagle_stage1_epoch_{epoch}.pth"
            torch.save({
                'epoch': epoch,
                'router_state_dict': text_router.state_dict(),
                'stage1_state_dict': stage1_model.state_dict()
            }, save_path)
            logger.info(f" 权重已安全保存至: {save_path}")

if __name__ == "__main__":
    main()