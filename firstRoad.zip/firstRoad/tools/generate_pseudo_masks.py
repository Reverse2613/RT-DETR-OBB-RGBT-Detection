# tools/generate_pseudo_masks.py
import sys
import os
# 为了能在 tools 目录下直接运行，将根目录加入环境变量
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import torch
import numpy as np
import cv2
from PIL import Image
from tqdm import tqdm
from transformers import OneFormerProcessor, OneFormerForUniversalSegmentation

from config import CFG
from utils.logger import logger
from data.skyfind_parser import SkyFindParser

class PseudoMaskGenerator:
    """
    调用 ADE20K 模型，为无人机图像生成地理拓扑伪掩码。
    """
    def __init__(self):
        self.device = CFG.DEVICE
        logger.info(f"正在加载大模型 {CFG.SEG_MODEL_ID} 到显卡 {self.device}...")
        
        try:
            self.processor = OneFormerProcessor.from_pretrained(CFG.SEG_MODEL_ID)
            self.model = OneFormerForUniversalSegmentation.from_pretrained(CFG.SEG_MODEL_ID).to(self.device)
            self.model.eval() # 冻结网络，纯推理模式
            logger.info("模型加载完成，准备生成伪标签。")
        except Exception as e:
            logger.error(f"模型下载或加载失败，请检查HuggingFace网络连接: {e}")
            raise e

    def process_single_image(self, image_path: str, save_path: str) -> bool:
        """处理单张图片并保存 Mask"""
        if not os.path.exists(image_path):
            logger.warning(f"图片不存在，跳过: {image_path}")
            return False

        try:
            # 1. 安全读取图片
            image = Image.open(image_path).convert("RGB")
            
            # 2. 预处理
            inputs = self.processor(images=image, task_inputs=["semantic"], return_tensors="pt")
            inputs = {k: v.to(self.device) for k, v in inputs.items()}
            
            # 3. 推理 (关闭梯度，节省显存)
            with torch.no_grad():
                outputs = self.model(**inputs)
                
            # 4. 后处理获取单通道类别矩阵 (0-149)
            predicted_map = self.processor.post_process_semantic_segmentation(
                outputs, target_sizes=[image.size[::-1]]
            )[0].cpu().numpy()

            # 5. 保存一张彩色的可视化图
            colored_map = self._colorize_mask(predicted_map)
            cv2.imwrite(save_path, colored_map)
            return True
            
        except Exception as e:
            logger.error(f"处理图片 {image_path} 时发生崩溃: {e}")
            return False

    def _colorize_mask(self, mask: np.ndarray) -> np.ndarray:
        """内部方法：将单通道类别的 mask 染色，涵盖无人机视角的 15 大核心拓扑"""
        colored = np.zeros((*mask.shape, 3), dtype=np.uint8)
        
        # ADE20K 核心类别映射 (注意 OpenCV 使用的是 BGR 格式，所以颜色通道是倒过来的)
        # --- 基础设施与地面 ---
        colored[mask == 6]  =[128, 64, 128]  # Road (马路/街道) - 紫色 
        colored[mask == 11] = [244, 35, 232]  # Sidewalk (人行道) - 粉紫色
        colored[mask == 1]  =[70, 70, 70]    # Building (建筑/楼房) - 灰色
        colored[mask == 0]  =[102, 102, 156] # Wall (墙壁) - 蓝灰色
        colored[mask == 3]  = [80, 50, 50]    # Floor (铺装地面/广场) - 深棕
        
        # --- 自然地貌 ---
        colored[mask == 2]  = [250, 170, 30]  # Sky (天空) - 亮蓝色 (BGR)
        colored[mask == 4]  =[34, 139, 34]   # Tree (树木/森林) - 深绿色
        colored[mask == 9]  =[144, 238, 144] # Grass (草地) - 浅绿色
        colored[mask == 13] = [30, 105, 210]  # Earth/Dirt (泥土地) - 橙土色
        colored[mask == 16] =[150, 100, 100] # Mountain (山脉) - 灰褐色
        colored[mask == 21] = [255, 0, 0]     # Water (水体/河流) - 纯蓝色
        colored[mask == 26] =[255, 100, 0]   # Sea (大海) - 深蓝色
        colored[mask == 46] =[0, 255, 255]   # Sand (沙滩) - 黄色
        
        # --- 动态目标 (这些也会被找出来，但我们主要靠它们定位相对位置) ---
        colored[mask == 12] = [60, 20, 220]   # Person (人) - 红色
        colored[mask == 20] =[0, 0, 142]     # Car (车) - 深蓝色
        
        return colored


def main():
    logger.info("===  启动 Eagle-REC 全量数据基建阶段 ===")
    
    # 1. 我们要把训练集和验证集一起处理了！
    target_jsons =[CFG.VAL_JSON, CFG.TRAIN_JSON]
    
    # 【神级优化】：用 Set 集合保存唯一的图片名，防止同一张图片被多个自然语言指令重复生成！
    unique_image_names = set()
    
    for json_path in target_jsons:
        if not os.path.exists(json_path):
            logger.warning(f"[!] 找不到文件，跳过: {json_path}")
            continue
            
        logger.info(f"正在解析: {json_path}")
        parser = SkyFindParser(json_path=json_path)
        annotations = parser.load_data()
        
        for ann in annotations:
            img_name = ann.get("fileName", "")
            if img_name:
                unique_image_names.add(img_name)
                
    logger.info(f"解析完毕！全量数据中共包含 {len(unique_image_names)} 张不重复的无人机图片！")
    
    if len(unique_image_names) == 0:
        logger.error("没有提取到任何图片，程序退出。")
        return
        
    # 2. 启动大模型生成器
    generator = PseudoMaskGenerator()
    
    success_count = 0
    logger.info("开始进行离线全量蒸馏掩码生成 (支持断点续传)...")
    
    # 3. 进度条遍历去重后的图片列表
    for img_name in tqdm(list(unique_image_names), desc="Generating All Masks"):
        img_full_path = os.path.join(CFG.IMAGE_DIR, img_name)
        # 把原图后缀替换为 .png 作为 mask 名字
        # 注意: opencv 保存 mask 通常用 png 最好，因为无损
        out_mask_path = os.path.join(CFG.MASK_OUT_DIR, f"mask_{img_name.replace('.jpg', '.png')}")
        
        # 【断点续传安全锁】：如果文件已经存在，直接跳过，极大地节约算力！
        if os.path.exists(out_mask_path):
            success_count += 1
            continue
            
        # 确保输出目录的子文件夹结构存在
        os.makedirs(os.path.dirname(out_mask_path), exist_ok=True)
        
        # 执行生成
        if generator.process_single_image(img_full_path, out_mask_path):
            success_count += 1
            
    logger.info(f"=== 全量 Mask 生成完毕！成功率: {success_count}/{len(unique_image_names)} ===")

if __name__ == "__main__":
    main()