# main.py
import argparse
import torch
import os
os.environ["TOKENIZERS_PARALLELISM"] = "false"  # 关闭底层分词器并行警告

from torch.utils.data import DataLoader

from config import CFG
from utils.logger import logger
from models.text_router import TriGranularityTextRouter
from data.skyfind_parser import SkyFindParser
from data.dataset import SkyFindDataset

from models.language_encoder import BERTEncoder
from models.stage1_macro import Stage1MacroNetwork

from engine.trainer import Stage1Trainer

def parse_args():
    parser = argparse.ArgumentParser(description="Eagle-REC Training Pipeline")
    parser.add_argument("--mode", type=str, default="train", choices=["train", "eval", "test"])
    parser.add_argument("--device", type=str, default=CFG.DEVICE)
    return parser.parse_args()

def main():
    args = parse_args()
    logger.info(f"====== Starting Eagle-REC in {args.mode.upper()} mode ======")
    
    # ---------------------------------------------------------
    # 模块 1：数据基建加载测试
    # ---------------------------------------------------------
    logger.info("Initializing Data Pipeline...")
    try:
        # 1. 解析 Json
        parser = SkyFindParser(json_path=CFG.VAL_JSON)
        annotations = parser.load_data()
        
        # 2. 挂载 Dataset
        # 为了测试，只传入前 50 条数据
        dataset = SkyFindDataset(
            annotations=annotations[:50], 
            image_dir=CFG.IMAGE_DIR, 
            mask_dir=CFG.MASK_OUT_DIR,
            target_size=CFG.stage1_input_size
        )
        
        # 3. 挂载 DataLoader (设置好 batch_size 和 worker)
        dataloader = DataLoader(
            dataset, 
            batch_size=CFG.batch_size, # 你的 L20 可以随便开到 16 甚至 32
            shuffle=False, 
            num_workers=4, 
            drop_last=True
        )
        
        logger.info(f"DataLoader 就绪，每个 Batch 大小: {CFG.batch_size}")
        
    except Exception as e:
        logger.error(f"数据流构建失败: {e}")
        return

    # ---------------------------------------------------------
    # 模块 2：Text Router 与 DataLoader 的联调测试
    # ---------------------------------------------------------
    logger.info("Initializing Tri-Granularity Text Router...")
    text_router = TriGranularityTextRouter(hidden_dim=CFG.hidden_dim).to(args.device)
    
    # 我们抽取第一个 Batch 出来检验系统的健壮性
    logger.info("=== 开始抽取首个 Batch 进行张量维度审计 ===")
    for batch_idx, batch_data in enumerate(dataloader):
        
        img_stage1 = batch_data["img_stage1"].to(args.device)
        semantic_mask = batch_data["semantic_mask"].to(args.device)
        norm_bbox = batch_data["norm_bbox"].to(args.device)
        expressions = batch_data["expression"]  # 这是一个 tuple of strings
        orig_paths = batch_data["orig_img_path"]
        
        logger.info(f"1. 阶段一压缩原图 Shape: {img_stage1.shape}")      # 应为[B, 3, 512, 512]
        logger.info(f"2. 拓扑蒸馏掩码 Shape: {semantic_mask.shape}")  # 应为 [B, 512, 512]
        logger.info(f"3. 归一化 GT 坐标 Shape: {norm_bbox.shape}")    # 应为[B, 4]
        logger.info(f"4. 读取到的文本指令示例: '{expressions[0]}'")
        logger.info(f"5. 为阶段二保留的高清原图路径: {orig_paths[0]}")
        
        # 模拟文本特征 (假设文本已经过了 BERT 变成了 256 维向量)
        # TODO: 以后这里我们会接上真正的 BERT 提取器
        dummy_text_feature = torch.randn(CFG.batch_size, CFG.hidden_dim).to(args.device)
        
        # 测试解耦器
        t_geo, t_rel, t_obj = text_router(dummy_text_feature)
        logger.info(f"6. 文本解耦完成！Geo 特征 Shape: {t_geo.shape}") # 应为 [B, 256]
        

        # （只需补充导入代码即可）
        #from models.language_encoder import BERTEncoder
        #from models.stage1_macro import Stage1MacroNetwork
        
        logger.info("=== 测试真实文本编码器 ===")
        text_encoder = BERTEncoder(hidden_dim=256).to(args.device)
        # 将 DataLoader 里读出来的真实英文句子转换成 Tensor
        real_text_feat = text_encoder(list(expressions), args.device)
        logger.info(f"7. 真实文本编码 Shape: {real_text_feat.shape}")
        
        logger.info("=== 测试三粒度路由解耦真实特征 ===")
        t_geo, t_rel, t_obj = text_router(real_text_feat)
        
        logger.info("=== 测试 Stage 1 核心网络前向传播 ===")
        stage1_model = Stage1MacroNetwork(hidden_dim=256, num_topology_classes=15).to(args.device)
        
        pred_bbox, pred_semantic = stage1_model(img_stage1, t_geo, t_rel)
        
        logger.info(f"8. 预测候选框 Shape: {pred_bbox.shape} (完美符合归一化坐标！)")
        logger.info(f"9. 预测蒸馏拓扑掩码 Shape: {pred_semantic.shape} (准备好和伪标签算 Loss！)")
        logger.info("=== 阶段一全链路正向传播（Forward Pass）完美打通！ ===")

        # from engine.trainer import Stage1Trainer

        logger.info("=== 启动 Stage 1 宏观粗搜网络训练引擎 ===")
        
        # 实例化训练器
        trainer = Stage1Trainer(
            text_encoder=text_encoder,
            text_router=text_router,
            stage1_model=stage1_model,
            dataloader=dataloader,
            device=args.device,
            lr=1e-4
        )
        
        # 设定只跑 50 个 Epoch 进行快速验证
        num_epochs = 50
        for epoch in range(1, num_epochs + 1):
            trainer.train_epoch(epoch)
            
            # 保存权重模型 (Checkpoint)
            save_path = f"eagle_rec_stage1_epoch_{epoch}.pth"
            torch.save({
                'epoch': epoch,
                'router_state_dict': text_router.state_dict(),
                'stage1_state_dict': stage1_model.state_dict()
            }, save_path)
            logger.info(f" Epoch {epoch} 模型权重已安全保存至: {save_path}")

        logger.info("=== 阶段一敏捷验证训练圆满结束！ ===")
        


    logger.info("=== 系统全链路测试通过！基座搭建完美完成！ ===")

if __name__ == "__main__":
    main()